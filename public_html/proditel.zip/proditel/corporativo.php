<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=0.6, maximum-scale=0.6, user-scalable=0"/>
<script type="text/javascript" src="jquery/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="jquery/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="jquery/jquery.mousewheel.js"></script>
<link href="https://fonts.googleapis.com/css?family=Fira+Sans&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Archivo+Black|Paytone+One&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/be342632af.js"></script>
<script type="text/javascript" src="js/navbar.js"></script>
<link rel="stylesheet" type="text/css" href="css/general.css">
<link rel="stylesheet" type="text/css" href="css/navbar.css">
<title>Proditel</title>
<style type="text/css">
	
</style>
</head>
<body>
	<div id="container">
		<?php include 'navbar.php';?>
	  <div id="subcont">
	  		<div id="banner2" style="background-image: url(img/corporativo.png);" class="tableo">
			  <span class="tablei wtitle">SERVICIOS CORPORATIVOS</span>
			</div>
		  <div class="inwidth2" style="text-align: center; margin-top: 80px;">
		  							<span class="fa-stack fa-3x">
									  <i class="fas fa-circle fa-stack-2x" style="color:#1c64ac"></i>
									  <i class="fas fa-building fa-stack-1x fa-inverse"></i>
									</span>
		  	<h1 class="h2in">PLANES Y TARIFAS PREMIUM</h1><br>
		  	<h2 class="h22in">Internet Premium 4Mbps</h2>
		  	<ul class="rates_c">
					<li class="rates">Velocidad de Descarga - 4Mbps</li>
					<li class="rates">Velocidad de Subida - 2Mbps</li>
				</ul>

		  	<ul class="rates_c">
					<li class="rates" style="padding-bottom: 30px; color: #00adef;">$101.150 IVA incluido</li>
				</ul>
		  	
		  	
		  </div>
		 <section id="servicios" style="background-color: #fbfbfb; padding-bottom: 50px;">
			<div class="inwidth2">
		  
				<h2 class="h22in">Internet Premium 5Mbps</h2>
		  	<ul class="rates_c">
					<li class="rates">Velocidad de Descarga - 5Mbps</li>
					<li class="rates">Velocidad de Subida - 3Mbps</li>
				</ul>

		  	<ul class="rates_c">
					<li class="rates" style="color: #00adef;">$130.900</li>
				</ul>
			 </div>
		  </section>
			<section id="servicios" style="background-color: white; padding-bottom: 50px;">
				<div class="inwidth2">
					<h2 class="h22in">Internet Premium 6Mbps</h2>
		  	<ul class="rates_c">
					<li class="rates">Velocidad de Descarga - 6Mbps</li>
					<li class="rates">Velocidad de Subida - 3Mbps</li>
				</ul>

		  	
		  	<ul class="rates_c">
					<li class="rates" style="color: #00adef;">$142.800</li>
				</ul>
				</div>
		  </section>
		  <section id="servicios" style="background-color: #fbfbfb; padding-bottom: 50px;">
				<div class="inwidth2">
					<h2 class="h22in">Internet Premium 7Mbps</h2>
		  	<ul class="rates_c">
					<li class="rates">Velocidad de Descarga - 7Mbps</li>
					<li class="rates">Velocidad de Subida - 4Mbps</li>
				</ul>

		  	
		  	<ul class="rates_c">
					<li class="rates" style="color: #00adef;">$166.600</li>
				</ul>
				</div>
		  </section>
		  <section id="servicios" style="background-color: white; padding-bottom: 50px;">
				<div class="inwidth2">
					<h2 class="h22in">Internet Premium 8Mbps</h2>
		  	<ul class="rates_c">
					<li class="rates">Velocidad de Descarga - 8Mbps</li>
					<li class="rates">Velocidad de Subida - 4Mbps</li>
				</ul>

		  	
		  	<ul class="rates_c">
					<li class="rates" style="color: #00adef;">$190.400</li>
				</ul>
				</div>
		  </section>
		  <section id="servicios" style="background-color: #fbfbfb; padding-bottom: 50px;">
				<div class="inwidth2">
					<h2 class="h22in">Internet Premium 9Mbps</h2>
		  	<ul class="rates_c">
					<li class="rates">Velocidad de Descarga - 9Mbps</li>
					<li class="rates">Velocidad de Subida - 5Mbps</li>
				</ul>

		  	
		  	<ul class="rates_c">
					<li class="rates" style="color: #00adef;">$214.200</li>
				</ul>
				</div>
		  </section>
		  <section id="servicios" style="background-color: white; padding-bottom: 50px;">
				<div class="inwidth2">
					<h2 class="h22in">Internet Premium 10Mbps</h2>
		  	<ul class="rates_c">
					<li class="rates">Velocidad de Descarga - 10Mbps</li>
					<li class="rates">Velocidad de Subida - 5Mbps</li>
				</ul>

		  	
		  	<ul class="rates_c">
					<li class="rates" style="color: #00adef;">$238.000</li>
				</ul>
				</div>
		  </section>
		   <section id="servicios" style="background-color: white; padding-bottom: 50px;">
				<div class="inwidth2">
					<a href="contrato.pdf" target="_blank"><span class="h22in">Ver modelo de contrato</span></a>
				</div>
		  </section>
		<?php include 'footer.php';?>
       		
        </div>
	</div>
	
</body>
</html>


