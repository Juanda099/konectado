<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=0.6, maximum-scale=0.6, user-scalable=0"/>
<script type="text/javascript" src="jquery/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="jquery/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="jquery/jquery.mousewheel.js"></script>
<link href="https://fonts.googleapis.com/css?family=Fira+Sans&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Archivo+Black|Paytone+One&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/be342632af.js"></script>
<script type="text/javascript" src="js/navbar.js"></script>
<link rel="stylesheet" type="text/css" href="css/general.css">
<link rel="stylesheet" type="text/css" href="css/navbar.css">
<title>Proditel</title>
<style type="text/css">
	
</style>
</head>
<body>
	<div id="container">
		<?php include 'navbar.php';?>
	  <div id="subcont">
	  		<div id="banner2" style="background-image: url(img/parental.png);" class="tableo">
			  <span class="tablei wtitle">CONTROL PARENTAL</span>
			</div>
		  <div class="inwidth2" style="text-align: left; margin-top: 80px;">
			
			 <p> En TIC confío es la estrategia de promoción de uso responsable de internet y de las nuevas tecnologías del Ministerio de las Tecnologías de la Información y las Comunicaciones. Ayuda a la sociedad a desenvolverse e interactuar responsablemente con las TIC, al tiempo que promueve la cero tolerancia con la pornografía infantil y la convivencia digital. En cumplimiento de la Ley 679 de 2001 y Decreto 1524 de 2002, Colombia Telecomunicaciones S.A. E.S.P. previene la divulgación de material de pornografía infantil a través de las redes y equipos de cómputo bajo su directa administración.<br>
				<br>


				En los siguientes lugares se pueden realizar denuncias relacionadas con sitios y contenidos de pornografía infantil, así como páginas web que ofrezcan servicios sexuales con niños:<br>
				<br>

				<strong>Ministerio de las tecnologías de la información y las comunicaciones</strong><br>

									<a href="http://www.enticconfio.gov.co/" target="_blank">www.enticconfio.gov.co/</a><br>

				<a href="http://www.teprotejo.org" target="_blank">www.teprotejo.org</a><br>
				 o descarga el app en las tiendas iOS o Android.<br>
				<br>
				<strong>Fiscalia General de la Nacion</strong><br>
				Teléfono: 01 800 0912280<br>

				www.fiscalia.gov.co<br>
				<br>
				<strong>Dirección central de policía judicial - dijin</strong><br>
				Grupo investigativo delitos informáticos<br>
				carrera 77a # 45-61 barrio modelia<br>
				teléfonos: pbx: 426 6900 ext. 6301-6302<br>
				directo: 4266300<br><br>


				<strong>Instituto colombiano de bienestar familiar</strong><br>
				Línea gratuita nacional icbf:(57 1) 01 8000 91 80 80. Disponible de lunes a domingo las 24 horas.<br>
				Línea de prevención abuso sexual:(57 1) 01 8000 11 24 40. Disponible de lunes a domingo las 24 horas.<br><br>
				Canales de atención en línea:<br>
				chat icbf y llamada en línea disponibles de lunes a domingo las 24 horas.<br>
				Videollamada disponible de lunes a viernes de 7:00 am a 7:00 pm en jornada continua.<br>
				Correo de atención al ciudadano.<br>
				Www.icbf.gov.co</p><br>

						<h2>Normas ley 679 de 2001 (agosto 3)</h2><br>
				<p>
				Diario oficial no. 44.509 del 4 de agosto de 2001por medio de la cual se expide un estatuto para prevenir y contrarrestar la explotación, la pornografía y el turismo sexual con menores, en desarrollo del artículo 44 de la constitución.<br>
				<br>
				<a href="Ley 679 de 2001.pdf" target="_blank">Descargar ley 679 de 2001</a>	


				</p><br>
					   <h2>Decreto número 067 de 2003 (enero 15)</h2><br>
				<p>
				Diario oficial 45. 066 17-01-2003 ministerio de comunicaciones que el 24 de julio de 2002 se expidió el decreto 1524 de 2002, el cual tiene por objeto reglamentar el artículo 5° de la ley 679 de 2001, con el fin de establecer las medidas técnicas y administrativas destinadas a prevenir el acceso de menores de edad a cualquier modalidad de información pornográfica contenida en internet o en las distintas clases de redes informáticas a las cuales se tenga acceso mediante redes globales de información.<br>
				<br>
				<a href="Decreto 067.pdf" target="_blank">descargar archivo decreto 067 de 2003 prórroga (25 kb)</a>


				</p><br>
					   <h2>Decreto número 1524 de 2002 (julio 24)</h2><br>
				<p>
				 Publicado el 31 de julio de 2002 ministerio de comunicaciones por el cual reglamenta el artículo 5° de la ley 679 de 2001, que de conformidad con lo dispuesto por el artículo 44 de la constitución política, los niños serán protegidos contra toda forma de abandono, violencia física o moral, secuestro, venta, abuso sexual, explotación laboral o económica y trabajos riesgosos.<br>
				<br>
				<a href="Decreto 1524 de 2002.pdf" target="_blank">descargar archivo decreto 1524-02 mincomunicaciones (35 kb)</a>



				</p><br>
						<h2>Control Parental</h2><br>
				<p>
				 Las siguientes son algunas aplicaciones que puede utilizar para el control del uso del internet por parte de sus hijos.<br>
				<br>


				<a href="http://www1.k9webprotection.com/" target="_blank">K9 Web Protection</a><br>


				<a href="https://www.netnanny.com/" target="_blank">Net Nanny</a><br>


				<a href="https://www.opendns.com/home-internet-security/" target="_blank">Open DNS</a>



				</p>

		  </div>
		  </div>
      		<section id="cobertura">
				<div id="map_canvas" class="bordert" style="width: 100%; height: 376px;"></div>
						<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBLsIXyGWmytDNc91Mq2VMfEH9oytRp9Ec&callback=initMap"></script>
						<script>
						// This example displays a marker at the center of Australia.
						// When the user clicks the marker, an info window opens.

						function initialize() {
						  var tame = new google.maps.LatLng(6.458177, -71.738116);

						  var mapOptions = {
							zoom: 9,
							center: tame,
							  zoomControl: true,
							  scaleControl: false,
							  scrollwheel: false,
							  disableDoubleClickZoom: true,
						  };

						  var map = new google.maps.Map(document.getElementById('map_canvas'), mapOptions);


						  var mriosucio = new google.maps.Marker({
							  position: tame,
							  map: map,
							  title: 'Tame'
						  });



						}

						google.maps.event.addDomListener(window, 'load', initialize);

						</script>
      		</section>
       		
		<?php include 'footer.php';?>
       		
        </div>
	</div>
	
</body>
</html>


