<!-- Header -->
				<div id="header" class="borders" style="border-radius: 0px !important">
					<div class="inwidth">
						<div class="tableo w25 borderl">
							<div class="tablei"><span class="fas fa-phone"> </span> (350) 368-9195/ (318) 473-8989</div>
						</div> 
						<div class="tableo w25 borderl borderr">
							<div class="tablei"><span class="far fa-envelope"> </span> contactoproditel@gmail.com</div>
						</div> 
					</div>
				</div>
			<!-- Header ends here -->