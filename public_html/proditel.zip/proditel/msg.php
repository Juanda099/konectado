<div class="divmsgcont">
	<div class="msg tableo">
		<span class="tablei">
			Su mensaje ha sido enviado correctamente<br>
			<div id="ok" class="button1">OK</div>
		</span>
	</div>
</div>