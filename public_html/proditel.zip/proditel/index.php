<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=0.6, maximum-scale=0.6, user-scalable=0"/>
<script type="text/javascript" src="jquery/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="jquery/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="jquery/jquery.mousewheel.js"></script>
<link href="https://fonts.googleapis.com/css?family=Fira+Sans&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Archivo+Black|Paytone+One&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/be342632af.js"></script>
<script type="text/javascript" src="js/navbar.js"></script>
<link rel="stylesheet" type="text/css" href="css/general.css">
<link rel="stylesheet" type="text/css" href="css/navbar.css">
<title>Proditel</title>
<style type="text/css">

</style>
</head>
<body>
	<div id="container">
				<?php include 'header.php';?>
			<!-- Nav Bar -->
			<div id="navbarcont" class="borderb">
					<div class="inwidth">
						<a href="index.php"><div id="logo"><img src="img/logo2.png" width="100%"></div></a>
						<div id="navbuttcont">
							<a href="index.php"><div id="button" class="w14 tableo borderl but">
								<span class="tablei">Inicio</span>
							</div></a>
							<a href="#acerca"><div id="button" class="w14 tableo borderl but">
								<span class="tablei">Acerca de</span>
							</div></a>
							<a href="#servicios"><div id="button" class="w14 tableo borderl but">
								<span class="tablei">Servicios</span>
							</div></a>
							<a href="#soporte"><div id="button" class="w14 tableo borderl but">
								<span class="tablei">Soporte</span>
							</div></a>
							<a href="#proteccion"><div id="button" class="w14 tableo borderl but">
								<span class="tablei">Proteccion</span>
							</div></a>
							<a href="https://www.zonapagos.com/t_Proditelsas" target="_blank"><div id="button" class="w14 tableo borderl but">
								<span class="tablei">Pagar Factura</span>
							</div></a>
							<a href="contactenos.php"><div id="button" class="w14 tableo borderl borderr but">
								<span class="tablei">Contactenos</span>
							</div></a>
						</div>
					</div>

			</div>

			<!-- Nav bar ends here -->
			<!-- Mobile Nav Bar -->
	
				<div id="mobilelogocont" class="borderb">
					<div id="menubut" onClick="menu()"><i class="fas fa-bars fa-2x"></i></div>
					<img src="img/logo.png" width="200px;">
				</div>

				<div id="navmobilecont">
					<a href="index.php"><div class="mob-but borderb">
						<div class="tableo but">
							<span class="tablei">Inicio</span>
						</div>
					</div></a>
					<a href="#acerca"><div class="mob-but borderb">
						<div class="tableo but">
							<span class="tablei">Acerca de</span>
						</div>
					</div></a>
					<a href="#servicios"><div class="mob-but borderb">
						<div class="tableo but">
							<span class="tablei">Servicios</span>
						</div>
					</div></a>
					<a href="#soporte"><div class="mob-but borderb">
						<div class="tableo but">
							<span class="tablei">Soporte</span>
						</div>
					</div></a>
					<a href="#proteccion"><div class="mob-but borderb">
						<div class="tableo but">
							<span class="tablei">Proteccion</span>
						</div>
					</div></a>
					<a href="contactenos.php"><div class="mob-but borderb">
						<div class="tableo but">
							<span class="tablei">Contactenos</span>
						</div>
					</div></a>
				</div>

				<!-- Mobile Nav Bar ends here -->

				<script>
			function menu(){
				var margin = $("#navmobilecont").css("left");

				if(margin == "-300px"){
					$('#navmobilecont').stop().animate({left: 0},400,'easeOutQuint');
				}
				else {
					$('#navmobilecont').stop().animate({left: -300},400,'easeOutQuint');
				}

			}

			</script>
	<!-- Nav bar ends here -->
		
			<script>

				$('a[href^="#"]').click(function (e) {
						e.preventDefault();

						var target = this.hash;
						var $target = $(target);

						$('html, body').stop().animate({
							'scrollTop': $target.offset().top
						}, 1000, 'easeOutQuint', function () {
							window.location.hash = target;
						});
					});

				</script>
		
	  <div id="subcont">
			<img src="img/banner2.jpg" width="100%" alt=""/>
<section id="acerca">
	  <div class="inwidth">
					<p class="par padtyb">
						Somos una empresa con mucha experiencia en redes inalámbricas, que lleva el servicio de INTERNET a zonas urbanas y también rurales de difícil acceso en Girardot, Nariño, Guataquí, Beltrán, Pulí, Jerusalén, Tocaima, Viotá, Agua De Dios, Nilo, Ricaurte,  Flandes, Melgar, Carmen de Apicalá, Ambalema, sin limitarnos solo a ellos. Podemos llegar adonde se requiera el servicio de Internet.<br>
<br>


La calidad de los equipos que empleamos y el alto nivel de servicio nos ha permitido suplir las necesidades de establecimientos educativos y entidades de gobierno local, empresas y hogares en todos estos municipios.<br>
<br>


Cumplimos con todas las normas para telecomunicaciones públicas de acuerdo con la regulación desarrollada por la Comisión de Regulación de Comunicaciones, MINTIC y ANE, asegurando a nuestros clientes y usuarios altos niveles de calidad de servicio y de atención al cliente

<br><br>

					</p>
				</div>      		
       		</section>
			<section id="servicios" style="background-color: #fbfbfb; padding-bottom: 50px;">
				<div class="inwidth-block">
							<div class="w50">
								<div class="wi90 borders">
									<span class="fa-stack fa-3x">
									  <i class="fas fa-circle fa-stack-2x" style="color:#2068b0"></i>
									  <i class="fas fa-home fa-stack-1x fa-inverse"></i>
									</span>
									<h2>PLANES RESIDENCIALES</h2>
									<span>Nos ajustamos a su presupuesto con y necesidades. Calidad y servicio del más alto nivel, para zonas urbanas y rurales dentro de nuestra zona de cobertura.</span>
									<a href="residenciales.php"><div class="button1">Mas Informacion</div></a>
								</div>
							</div>  
							<div class="w50">
								<div class="wi90 borders">
									<span class="fa-stack fa-3x">
									  <i class="fas fa-circle fa-stack-2x" style="color:#2068b0"></i>
									  <i class="fas fa-building fa-stack-1x fa-inverse"></i>
									</span>
									<h2>PLANES CORPORATIVOS</h2>						
									<span>Con soluciones a la medida, y con muy alta calidad de servicio, proveemos soluciones especificas  a sus necesidades empresariales o institucionales.</span>
									<a href="corporativo.php"><div class="button1">Mas Informacion</div></a>
								</div>
							</div>
				    		
   		  </section>
       		
   		  <section style="padding-top: 0px;">
	     	 <img src="img/banner22.jpg" width="100%" alt=""/> 
      	  </section>
       		
   		  <section id="soporte" style="padding-top: 0px; background-color: #fbfbfb;">
   			  <div id="banner-back">
   			  
					<div class="inwidth-block">
						<a href="pqr/upload"><div class="w25">
					  	  <div class="wi90p20 borders" style="background-color: white; text-align: center;">						
								 <i class="fas fa-file-alt fa-3x" style="color:#1c64ac"></i>

								<div class="el-tit tableo"><h3 class="tablei" style="color:#1c64ac">PQR</h3></div>						
								<span>Radique y consulte el estado de su PQR.</span>
							</div>
						</div></a>
     					<a href="medidor.php"><div class="w25">
					  	  <div class="wi90p20 borders" style="background-color: white;">						
								 <i class="fas fa-tachometer-alt fa-3x" style="color:#1c64ac"></i>

								<div class="el-tit tableo"><h3 class="tablei" style="color:#1c64ac">MEDIDOR DE VELOCIDAD</h3></div>						
								<span>Mida la velocidad de su conexion a internet.</span>
							</div>
						</div></a>
     					<a href="disponibilidad.pdf" target="_blank"><div class="w25">
					  	  <div class="wi90p20 borders" style="background-color: white;">						
								 <i class="fas fa-chart-line fa-3x" style="color:#1c64ac"></i>

								<div class="el-tit tableo"><h3 class="tablei" style="color:#1c64ac">INDICADORES DE DISPONIBILIDAD</h3></div>						
								<span>Indicadores de calidad de nuestros servicios.</span>
							</div>
     					</div></a>
     					<a href="caracteristicas.php"><div class="w25">
					  	  <div class="wi90p20 borders" style="background-color: white;">						
								 <i class="fas fa-clipboard-list fa-3x" style="color:#1c64ac"></i>

								<div class="el-tit tableo"><h3 class="tablei" style="color:#1c64ac">CARACTERISTICAS DEL SERVICIO</h3></div>						
								<span>Caracteristicas de nuestros servicios.</span>
							</div>
						</div></a>
					</div>
    				<a href="ficha tecnica.pdf" target="_blank"><div class="inwidth-block">
     					<div class="w25">
					  	  <div class="wi90p20 borders" style="background-color: white;">						
								 <i class="fas fa-list fa-3x" style="color:#1c64ac"></i>

								<div class="el-tit tableo"><h3 class="tablei" style="color:#1c64ac">FICHA TECNICA MODEMS</h3></div>						
								<span>Informacion sobre nuestros dispositivos.</span>
							</div>
						</div></a>
     					<a href="factores.php"><div class="w25">
					  	  <div class="wi90p20 borders" style="background-color: white;">						
								 <i class="fas fa-exclamation-triangle fa-3x" style="color:#1c64ac"></i>

								<div class="el-tit tableo"><h3 class="tablei" style="color:#1c64ac">FACTORES DE LIMITACION DE VELOCIDAD</h3></div>						
								<span>Facores que pueden estar limitando su servicio.</span>
							</div>
						</div></a>
     					<a href="informacion_crc.php"><div class="w25">
					  	  <div class="wi90p20 borders" style="background-color: white;">						
								 <i class="fas fa-glasses fa-3x" style="color:#1c64ac"></i>

								<div class="el-tit tableo"><h3 class="tablei" style="color:#1c64ac">INFORMACION CRC MODEMS</h3></div>						
								<span>Informacion de utilidad de la CRC.</span>
							</div>
						</div></a>
      				
      				
      				</div>       				
       			</div>
			</section>
     		
      		<section id="proteccion" style="background-color: #1c64ac;">
      			<div class="inwidth-block" style="color: white;">
					<a href="procedimientos.php"><div class="w33">
						<div class="wi90p20">
					    	<img src="img/procedimientos.jpg" class="rimg" width="100%" alt=""/> 
					    	<div class="el-tit tableo">
					    		<h3 class="tablei">PROCEDIMIENTOS PQR</h3>
					    	</div>
					    </div>
					</div></a>		
				
				
				
					<a href="atencion.pdf" target="_blank"><div class="w33">
						<div class="wi90p20">
					    	<img src="img/atencion.jpg" class="rimg" width="100%" alt=""/> 
					    	<div class="el-tit tableo">
					    		<h3 class="tablei">INDICADORES DE ATENCION AL USUARIO</h3>
					    	</div>
					    </div>
					</div></a>			
				
				
					<a href="control.php"><div class="w33">
						<div class="wi90p20">
					    	<img src="img/control.jpg" class="rimg" width="100%" alt=""/> 
					    	<div class="el-tit tableo">
					    		<h3 class="tablei">CONTROL PARENTAL</h3>
					    	</div>
					    </div>
					</div>	</a>			
				</div>
			</section>
     		
      		<section>
      			<div class="inwidth-block">
      				<a href="https://www.crcom.gov.co/es/pagina/regimen-proteccion-usuario" target="_blank"><img src="img/1562617504187.jpg" width="100%"></a>
				</div> 			
      			
      		</section>
      		
      		
       		
		<?php include 'footer.php';?>
       		
        </div>
	</div>
	
</body>
</html>


